package engine;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Query {

    private final List<Word> keywordList;

    public Query(String userInput) {
        this.keywordList = new ArrayList<>();
        Scanner inputScanner = new Scanner(userInput);
        while (inputScanner.hasNext()) {
            Word wordObject = Word.createWord(inputScanner.next());
            if (wordObject.isKeyword()) {
                keywordList.add(wordObject);
            }
        }
    }

    public List<Word> getKeywords() {
        return keywordList;
    }

    public List<Match> matchAgainst(Doc document) {
        List<Match> matchList = new ArrayList<>();
        if (document != null) {
            for (Word keyword : keywordList) {
                int occurrenceCount = 0, firstOccurrenceIndex = -1;
                for (int i = 0; i < document.getAllWords().size(); i++) {
                    if (document.getAllWords().get(i).equals(keyword)) {
                        occurrenceCount++;
                        if (firstOccurrenceIndex == -1) firstOccurrenceIndex = i;
                    }
                }
                if (occurrenceCount > 0) {
                    matchList.add(new Match(document, keyword, occurrenceCount, firstOccurrenceIndex));
                }
            }
            matchList.sort(Match::compareTo);
        }
        return matchList;
    }
}
