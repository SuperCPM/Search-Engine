package engine;

import java.io.*;
import java.nio.file.DirectoryStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;

public class Engine {

    private final List<Doc> documents = new ArrayList<>();
    private int documentCount = 0;

    public int loadDocs(String directoryName) {
        try(DirectoryStream<Path> stream = Files.newDirectoryStream(Path.of(directoryName))) {
            for (Path file : stream) {
                try(BufferedReader reader = new BufferedReader(new FileReader(file.toFile()))) {
                    String content = reader.lines().reduce("", (acc, line) -> acc + line + "\n");
                    Doc document = new Doc(content);
                    documents.add(document);
                    documentCount++;
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
            }
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        return documentCount;
    }

    public Doc[] getDocs() {
        return documents.toArray(new Doc[0]);
    }

    public List<Result> search(Query query) {
        List<Result> results = new ArrayList<>();
        for (int i = 0; i < documentCount; i++) {
            List<Match> matches = query.matchAgainst(documents.get(i));
            if(!matches.isEmpty()) {
                Result result = new Result(documents.get(i), matches);
                results.add(result);
            }
        }
        results.sort(Result::compareTo);
        return results;
    }

    public String htmlResult(List<Result> results) {
        StringBuilder htmlBuilder = new StringBuilder();
        for (Result result : results) {
            String highlight = result.htmlHighlight();
            if (highlight != null) {
                htmlBuilder.append(highlight);
            }
        }
        return htmlBuilder.toString();
    }
}
