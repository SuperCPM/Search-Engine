package engine;

import java.util.ArrayList;
import java.util.List;

public class Match implements Comparable<Match> {

    private final Doc document;
    private final Word word;
    private int frequency = 0;
    private int firstOccurrence;
    private List<Integer> indices;

    public Match(Doc document, Word word) {
        this.document = document;
        this.word = word;
        this.frequency = getFreq();
        this.firstOccurrence = getFirstIndex();
        this.indices = new ArrayList<>();
    }

    public Match(Doc document, Word word, int frequency, int firstOccurrence) {
        this.document = document;
        this.word = word;
        this.frequency = frequency;
        this.firstOccurrence = firstOccurrence;
        this.indices = new ArrayList<>();
    }

    public List<Integer> getIndex() {
        return indices;
    }

    public int getFreq() {
        this.indices = new ArrayList<>();
        this.frequency = 0;

        calculateFrequencyAndIndices(document.getTitle(), 0);
        calculateFrequencyAndIndices(document.getBody(), document.titleLength());

        return this.frequency;
    }

    private void calculateFrequencyAndIndices(List<Word> words, int offset) {
        for (int i = 0; i < words.size(); i++) {
            if (this.word.equals(words.get(i))) {
                this.indices.add(i + offset);
                this.frequency++;
            }
        }
    }

    public int getFirstIndex() {
        for (int i = 0; i < document.getAllWords().size(); i++) {
            if (this.word.equals(document.getAllWords().get(i))) {
                this.firstOccurrence = i;
                break;
            }
        }
        return firstOccurrence;
    }

    @Override
    public int compareTo(Match otherMatch) {
        return Integer.compare(this.getFirstIndex(), otherMatch.getFirstIndex());
    }

    public Word getWord() {
        return this.word;
    }
}
