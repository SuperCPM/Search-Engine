package engine;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Doc {
    private final List<Word> title;
    private final List<Word> body;
    private final List<Word> allWords;

    public Doc(String content) {
        this.title = new ArrayList<>();
        this.body = new ArrayList<>();
        this.allWords = new ArrayList<>();

        String[] lines = content.split("\n");
        addWordsToCollection(lines[0], title);
        addWordsToCollection(lines[1], body);
    }

    private void addWordsToCollection(String line, List<Word> wordList) {
        Scanner scanner = new Scanner(line);
        while (scanner.hasNext()) {
            Word word = Word.createWord(scanner.next());
            wordList.add(word);
            allWords.add(word);
        }
    }

    public List<Word> getTitle() {
        return title;
    }

    public List<Word> getBody() {
        return body;
    }

    public List<Word> getAllWords() {
        return allWords;
    }

    @Override
    public boolean equals(Object o) {
        if (o instanceof Doc) {
            Doc otherDoc = (Doc) o;
            return listEquals(otherDoc.title, this.title) && listEquals(otherDoc.body, this.body);
        }
        return false;
    }

    private boolean listEquals(List<Word> list1, List<Word> list2) {
        if (list1.size() != list2.size()) {
            return false;
        }
        for (int i = 0; i < list1.size(); i++) {
            if (!list1.get(i).equals(list2.get(i))) {
                return false;
            }
        }
        return true;
    }

    public int bodyLength() {
        return body.size();
    }

    public int titleLength() {
        return title.size();
    }
}
