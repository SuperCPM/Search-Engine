package engine;

import java.io.*;
import java.util.*;

public class Word {

    private final String prefix;

    private final String text;

    private final String suffix;

    public Word (String pre, String txt, String suf) {
        this.prefix = pre;
        this.suffix = suf;
        this.text = txt;
    }
    public static Set<String> stopWords;
    boolean isKeyword() {
        String text = this.getText().toLowerCase();
        if (text.isEmpty() || stopWords.contains(text)) {
            return false;
        }

        for (char c : text.toCharArray()) {
            if (Character.isDigit(c)) {
                return false;
            }
        }

        return true;
    }


    public String getPrefix() {
        return this.prefix;
    }

    public String getSuffix() {
        return this.suffix;
    }

    public String getText() {
        return this.text;
    }


    @Override
    public boolean equals(Object o) {
        if (o instanceof Word) {
            Word word = (Word) o;
            return this.getText().equalsIgnoreCase(word.getText());
        }
        return false;
    }

    public String toString() {
        return getPrefix() + getText() + getSuffix();
    }
    public static Word createWord(String rawText) {
        String pre = "";
        String txt = "";
        String suf = "";

        int len = rawText.length();
        int i = 0;

        while (i < len && !isALetter(rawText.charAt(i))) {
            pre += rawText.charAt(i);
            i++;
        }
        while (i < len) {
            char currentChar = rawText.charAt(i);
            char previousChar = (i > 0) ? rawText.charAt(i - 1) : 0;

            if (isALetter(currentChar) && !(currentChar == ',' && i > 1) && !(currentChar == '.' && (previousChar < '0' || previousChar > '9') && len - i < 3)) {
                txt += currentChar;
                i++;
            } else {
                break;
            }
        }
        while (i < len) {
            suf += rawText.charAt(i);
            i++;
        }
        return new Word(pre, txt, suf);

    }

    public static boolean isALetter(char c) {
        return (Character.isLetter(c) || c == ',' || c == '.' || c == '-' || (c >= '0' && c <= '9'));
    }

    public static boolean loadStopWords(String fileName) {
        stopWords = new HashSet<>();

        try (Scanner scanner = new Scanner(new File(fileName))) {
            int count = 0;
            while (scanner.hasNext()) {
                String word = scanner.next();
                stopWords.add(word);
                count++;
            }

            return !stopWords.isEmpty();
        } catch (FileNotFoundException e) {
            return false;
        }
    }


}